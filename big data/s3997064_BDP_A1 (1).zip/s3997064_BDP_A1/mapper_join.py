#!/usr/bin/env python3
import sys

for line in sys.stdin:
    line = line.strip()
    if line:
        parts = line.split(',')
        if len(parts) == 4:
            # Taxis.txt
            taxi_id, company, model, year = parts
            print(f"{taxi_id}\tcompany,{company}")
        elif len(parts) == 8:
            # Trips.txt
            trip_id, taxi_id, fare, distance, pickup_x, pickup_y, dropoff_x, dropoff_y = parts
            print(f"{taxi_id}\ttrip,1")