#!/bin/bash
hadoop jar ./hadoop-streaming-3.1.4.jar \
-D mapreduce.job.reduces=3 \
-input /Input/Trips.txt \
-output /Output/Task2 \
-mapper ./mapper_task2.py \
-reducer ./reducer_task2.py \
-file ./mapper_task2.py \
-file ./reducer_task2.py \
-file ./initialization.txt
