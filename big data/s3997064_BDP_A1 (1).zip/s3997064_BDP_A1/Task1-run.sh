#!/bin/bash
hdfs dfs -rm -r /Output/Task1
hdfs dfs -rm -r /Input
hdfs  dfs -mkdir  -p  /Input
hdfs dfs -put Trips.txt /Input
hadoop jar ./hadoop-streaming-3.1.4.jar \
-D mapred.reduce.tasks=3 \
-file ./mapper_task1.py \
-mapper ./mapper_task1.py \
-file ./reducer_task1.py \
-input /Input/Trips.txt \
-reducer ./reducer_task1.py \
-output /Output/Task1