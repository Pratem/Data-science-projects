INTRUCTIONS FOR RUNNING MY ASSIGNMENTS : 
The Sequence of running my assignmnet is Task 1 -> Task 2 -> Task 3 . 

The reason is the in the run script of Task 1 , i am creating the INPUT and OUTPUT directories 
and also puting the Taxis and Trip in the INPUT. So its important to run from the Task 1 . 
It starts by removing any existing output (/Output/Task1) and input (/Input) directories in HDFS,
then creates a fresh input directory (/Input) and uploads the Trips.txt file.The input file for the job is set to /Input/Trips.txt,
and the job's output is directed to /Output/Task1 . This is similar on the run script of Task 2 and Task 3 . 

Also note that Task 2 will take some time to execute . 

In Task 3 , for the Count, Join and Sort operation -> there are 3 mappers and 3 reducers for each operation named as:
mapper_count,mapper_join,mapper_sort
reducer_count, reducer_join,reducer_sort 

thank you .

