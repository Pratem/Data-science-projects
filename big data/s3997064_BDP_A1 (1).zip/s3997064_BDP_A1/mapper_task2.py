#!/usr/bin/env python3

import sys
import math

# Function to read the initialization file and extract the medoids and integer value
def input_initial(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()
        # Read the first line as an integer value
        x = int(lines[0].strip())
        # Read the remaining lines as tuples of floats representing medoids
        medoids = [tuple(map(float, line.strip().split())) for line in lines[1:]]
    return x, medoids

# Function to calculate the Euclidean distance between two points
def euclidean_distance(point1, point2):
    return math.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)

# Function to find the closest medoid to a given dropoff point
def closest_medoid(dropoff, medoids):
    distances = [euclidean_distance(dropoff, medoid) for medoid in medoids]
    # Return the medoid with the minimum distance to the dropoff point
    return medoids[distances.index(min(distances))]

# Main function to process input data and find the closest medoid for each dropoff point
if __name__ == "__main__":
    # Path to the initialization file
    initialization_file = 'initialization.txt'
    # Read the integer value and medoids from the initialization file
    x, medoids = input_initial(initialization_file)

    # Process each line from the standard input
    for line in sys.stdin:
        parts = line.strip().split(',')
        trip_id = parts[0]
        dropoff_x = float(parts[6])
        dropoff_y = float(parts[7])
        dropoff = (dropoff_x, dropoff_y)
        # Find the closest medoid for the dropoff point
        closest = closest_medoid(dropoff, medoids)
        # Print the closest medoid and the original line
        print(f"{closest}\t{line.strip()}")