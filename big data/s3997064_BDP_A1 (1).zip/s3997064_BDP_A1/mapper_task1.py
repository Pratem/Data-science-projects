#!/usr/bin/env python3
import sys

# Dictionary to hold values
dic_values = {}

def mapp_func():
    for key, values in dic_values.items():
        print(f"{key}\t{values['count']},{values['max_fare']},{values['min_fare']},{values['total_fare']}")

# Read input line by line
for line in sys.stdin:
    line = line.strip()
    if line:
        parts = line.split(',')
        if len(parts) == 8:
            taxi_id = parts[1]
            fare = float(parts[2])
            distance = float(parts[3])

            if distance >= 200:
                trip_type = 'long'
            elif distance >= 100:
                trip_type = 'medium'
            else:
                trip_type = 'short'

            key = f"{taxi_id},{trip_type}"

            if key not in dic_values:
                dic_values[key] = {'count': 0, 'max_fare': -float('inf'), 'min_fare': float('inf'), 'total_fare': 0.0}

            dic_values[key]['count'] += 1
            dic_values[key]['max_fare'] = max(dic_values[key]['max_fare'], fare)
            dic_values[key]['min_fare'] = min(dic_values[key]['min_fare'], fare)
            dic_values[key]['total_fare'] += fare

mapp_func()
