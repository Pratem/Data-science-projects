#!/usr/bin/env python3

import sys
import math
from collections import defaultdict

# Function to calculate the Euclidean distance between two points
def euclidean_distance(point1, point2):
    return math.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)

# Function to calculate the total cost (sum of distances) of all points in a cluster to a given medoid
def cost_value(cluster, medoid):
    return sum(euclidean_distance((float(trip[6]), float(trip[7])), medoid) for trip in cluster)

# Function to find the best medoid for a cluster by minimizing the total cost
def update_medoid(cluster):
    best_medoid = None
    best_cost = float('inf')
    for candidate in cluster:
        candidate_point = (float(candidate[6]), float(candidate[7]))
        cost = cost_value(cluster, candidate_point)
        if cost < best_cost:
            best_cost = cost
            best_medoid = candidate_point
    return best_medoid

# Main function to process input data and update medoids for each cluster
if __name__ == "__main__":
    current_medoid = None
    cluster = []

    # Process each line from the standard input
    for line in sys.stdin:
        medoid, trip = line.strip().split('\t')
        trip = trip.split(',')
        
        # Initialize the current medoid if it's not set
        if current_medoid is None:
            current_medoid = medoid
        
        # If the medoid changes, update the medoid for the current cluster
        if medoid != current_medoid:
            new_medoid = update_medoid(cluster)
            print(f"{current_medoid}\t{new_medoid}")
            current_medoid = medoid
            cluster = []
        
        # Add the trip to the current cluster
        cluster.append(trip)

    # Update the medoid for the last cluster if it exists
    if current_medoid is not None:
        new_medoid = update_medoid(cluster)
        print(f"{current_medoid}\t{new_medoid}")