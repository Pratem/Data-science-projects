#!/usr/bin/env python3
import sys

current_company = None
current_count = 0

for line in sys.stdin:
    line = line.strip()
    company, count = line.split('\t')
    count = int(count)
    
    if current_company == company:
        current_count += count
    else:
        if current_company:
            print(f"{current_company}\t{current_count}")
        current_company = company
        current_count = count

if current_company:
    print(f"{current_company}\t{current_count}")