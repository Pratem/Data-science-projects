#!/bin/bash


# Step 1: Join Operation

hdfs dfs -put Taxis.txt /Input
hdfs dfs -rm -r /output/join_output
hadoop jar ./hadoop-streaming-3.1.4.jar \
    -D mapreduce.job.reduces=3 \
    -input /Input/Trips.txt \
    -input /Input/Taxis.txt \
    -output /output/join_output \
    -mapper ./mapper_join.py \
    -reducer ./reducer_join.py \
    -file ./mapper_join.py \
    -file ./reducer_join.py

# Step 2: Counting Operation
hdfs dfs -rm -r /output/count_output
hadoop jar ./hadoop-streaming-3.1.4.jar \
    -D mapreduce.job.reduces=3 \
    -input /output/join_output \
    -output /output/count_output \
    -mapper ./mapper_count.py \
    -reducer ./reducer_count.py \
    -file ./mapper_count.py \
    -file ./reducer_count.py

# Step 3: Sorting Operation
hdfs dfs -rm -r /output/task_3
hadoop jar ./hadoop-streaming-3.1.4.jar \
    -D mapreduce.job.reduces=3 \
    -input /output/count_output \
    -output /Output/Task3 \
    -mapper ./mapper_sort.py \
    -reducer ./reducer_sort.py \
    -file ./mapper_sort.py \
    -file ./reducer_sort.py