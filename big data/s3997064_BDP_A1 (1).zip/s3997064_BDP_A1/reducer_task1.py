#!/usr/bin/env python3
import sys

# Dictionary to hold final results
final_values = {}

# Read input line by line
for line in sys.stdin:
    line = line.strip()
    if line:
        key, values = line.split('\t')
        count, max_fare, min_fare, total_fare = map(float, values.split(','))

        if key not in final_values:
            final_values[key] = {'count': 0, 'max_fare': -float('inf'), 'min_fare': float('inf'), 'total_fare': 0.0}

        final_values[key]['count'] += count
        final_values[key]['max_fare'] = max(final_values[key]['max_fare'], max_fare)
        final_values[key]['min_fare'] = min(final_values[key]['min_fare'], min_fare)
        final_values[key]['total_fare'] += total_fare



# Output final results
for key, values in final_values.items():
    avg_fare = values['total_fare'] / values['count']
    print(f"{key}\t{values['count']},{values['max_fare']},{values['min_fare']},{avg_fare}")