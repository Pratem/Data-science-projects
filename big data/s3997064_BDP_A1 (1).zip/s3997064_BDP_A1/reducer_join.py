#!/usr/bin/env python3
import sys

current_taxi_id = None
company = None
trips = []

for line in sys.stdin:
    line = line.strip()
    taxi_id, value = line.split('\t')
    value_type, value_data = value.split(',')

    if current_taxi_id != taxi_id:
        if current_taxi_id and company:
            for trip in trips:
                print(f"{company}\t{trip}")
        current_taxi_id = taxi_id
        company = None
        trips = []

    if value_type == 'company':
        company = value_data
    elif value_type == 'trip':
        trips.append(value_data)

if current_taxi_id and company:
    for trip in trips:
        print(f"{company}\t{trip}")