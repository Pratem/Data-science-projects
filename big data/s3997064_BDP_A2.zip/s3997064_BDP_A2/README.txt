Some basic infomation for running my assignment 
> Input
In task1 , the input directory has been created using the sh function. There is no nned to assume that input directory is created in 
HDFS. Inside the input directory , it has all the csv files . It is important to run the task1 >task2-1>task2-2 , in this sequence.

>output 
the output directory has the output for all the 3 task . 

> also make sure the udf.py file is in the same directory when running the task 2-2 .

> example: $ pig -x mapreduce task1.pig to run the task . 
