from pig_util import outputSchema

@outputSchema("tuple(region:chararray, gold:int, silver:int)")  # Changed output schema to return a single tuple
def add_zero(region, gold, silver):
    if silver is None:
        silver = 0
    return (region, gold, silver)  # Return a single tuple