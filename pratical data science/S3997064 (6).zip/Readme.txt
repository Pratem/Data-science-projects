Name:Pratham
Student ID: S3997064

Intructions to run the commands :
Dataset choosen :. Online Shoppers Purchasing Intention Dataset . Dataset already in csv format , no need to convert. Upload the dataset and run commands .