# Name: Pratham Radhakrishna
# ID Number: S3997064
# I have attempted till DI level 


##############################################################################
    
class Member:
    
    def __init__(self, member_id, Fnameofbook, Lnameofbook, date_of_birth, member_typeof):
        self.member_id = member_id # Unique identifier for the member
        
        self.Fnameofbook = Fnameofbook #First name of the member of book
        
        self.Lnameofbook = Lnameofbook #last  name of the member of book
        
        
        self.date_of_birth = date_of_birth # Date of birth of the member
        
        self.member_typeof = member_typeof #Type of membership
        
        self.borrowed_books = {}  #Dictionary to store borrowed books categorized by type
        
        
    def book_kind(self): #kind of books the member tends to borrow based on membership type.
        
        if self.member_typeof == 'Standard': #String indicating the kind of book
            if self.numberof_textbooks() > 1:
                return "Ntextbook!"
            
            if self.numberof_fictionalbooks() > 2:
                return "Nfiction!"
            
        elif self.member_typeof == 'Premium':
            if self.numberof_textbooks() > 2:
                return "Ntextbook!"
            
            if self.numberof_fictionalbooks() > 3:
                return "Nfiction!"
            
            
        return ""

    def get_calc(self): #calculations related to the member's borrowing history
        return self.numberof_textbooks(), self.numberof_fictionalbooks(), self.avg_days() #Number of fictional books borrowed.
    

    def avg_days(self): # average number of days books are borrowed by the member
        total_days = sum(
            
            days for book_days in self.borrowed_books.values() for days in book_days if isinstance(days, int)
        )
        total_books = sum(len(book_days) for book_days in self.borrowed_books.values())
        
        return total_days / total_books if total_books > 0 else 0  
    
    
    
    def numberof_textbooks(self):
        return len(self.borrowed_books.get('T',   [])) # Count the number of textbooks borrowed by the member

    def add_book(self, book_typeof, days):
        # Add a book to the member's borrowed books list
        if book_typeof not in self.borrowed_books: #Type of the book ('T' for textbook, 'F' for fictional book)
            self.borrowed_books[book_typeof] = [] 
        self.borrowed_books[book_typeof].append(days)  #Number of days the book is borrowed for.


    def numberof_fictionalbooks(self):
        return len(self.borrowed_books.get('F',   [])) #Count the number of fictional books borrowed

    
##############################################################################

class Book:
    
    def __init__(self, book_id_number, book__name,
    book_typeof, copies__number, maximum_days, late__charges):
        
        self.book_id_number =  book_id_number  # - book_id_number: Unique identifier for the book.
        
        self.book__name = book__name   # - book_name: Name of the book.
        
        self.book_typeof = book_typeof # - book_type: Type or category of the book.
        
        self.copies__number = copies__number  # - copies_number: Number of copies available.
        
        self.maximum_days = maximum_days    # - maximum_days: Maximum days allowed for borrowing the book.
        
        self.late__charges = late__charges   # - late_charges: Charges applicable if the book is returned late.
        
        self.days_borrow = {}       # - days_borrow: Dictionary to store borrowing information for members.
         
        
        

    def numberof_borrow_member(self):  # Count the number of members who have borrowed the book.
        return sum(1 for days in self.days_borrow.values() if days.isdigit()) # Number of members who have borrowed the book.

    def addingborrowday(self, member_id, days):  #ID of the member borrowing the book
         #Add or update the borrowing days for a member
         self.days_borrow[member_id] =  days #Number of days the book is borrowed for.
        

    def get_calc(self):
        
        nborrow = self.numberof_borrow_member()   # Number of members who have borrowed the book.        
        nappoints = self.number_appointments()    # Number of appointments (special case of borrowing).
        minimum_day, maximum_days = self.borrow_duration() #Minimum and maximum days borrowed 
        
        return nborrow, nappoints, minimum_day, maximum_days
    

    
    

    def number_appointments(self):
        return sum(1 for days in self.days_borrow.values() if days == 'R') # Number of appointments
    

    def borrow_duration(self): #the minimum and maximum days a book has been borrowed.
        days = [int(days) for days in self.days_borrow.values() if days.isdigit()]
        if days:
            
            return min(days), max(days)
        
        return None, None
    
    

   
    
    def gettingborrowedday(self, member_id): #number of days a member has borrowed the book
        return  self.days_borrow.get(member_id, 'xx')
    
    


##############################################################################    
        
class Records:
    def __init__(self): #  Initialize a Records object to manage books and members.
        
        self.books = {} #Dictionary to store book records where keys are book IDs
        
        self.members = {} # Dictionary to store member records where keys are member IDs
        
        
        
        
         
    def displaymember_deets(self): # Display detailed information about each member.
        if not self.members:
            print("No member information to display.") # If there are no members, it prints a message indicating no information is available.
            return
#Prints a formatted table showing member details including borrowed book types
        heading = "Member ID  Fbook__name        Lbook__name        Type      date_of_birth          Ntextbook  Nfiction  Average"
        print(heading)
        ##############################################################
        print("-" * len(heading))

# # Iterate over sorted members and display their details
        for member_id, member in sorted(self.members.items()):
            
            n_textbook, n_fiction, avg_days = member.get_calc()
            #  # Determine if there are any limit warnings for the member's book borrowing
            limit_check = member.book_kind()
            
            ## Format the row with member details
            row = f"{member_id:<10} {member.Fnameofbook:<12} {member.Lnameofbook:<12} {member.member_typeof:<9} {member.date_of_birth:<11} "
            
            # # Append formatted values for number of textbooks and fiction books
            if "Ntextbook!" in limit_check:
                row += f"{n_textbook}!        "
                
            else:
                row += f"{n_textbook:<9} "
                
            if "Nfiction!" in limit_check:
                row += f"{n_fiction}!      "
                
            else: ## Append formatted average days borrowed
                row += f"{n_fiction:<8} "
                
            row += f"{avg_days:>7.2f}"
            
            # # Print the formatted row for the member
            print(row)

    
            

    def book_deets(self, file_book__name): # Read book details from a file and update the records.
        try:
            
            with open(file_book__name, 'r') as file: #Name of the file containing book details.
                for line in file:
                    phase = line.strip().split(', ') ## Split the line into parts and strip whitespace
                    ## Extract attributes from the lin
                    book_id_number = phase[0]
                    book__name = phase[1]
                    book_typeof = phase[2]
                    copies__number = int(phase[3])
                    maximum_days = int(phase[4])
                    late__charges = float(phase[5])
                    
                    
                    if book_typeof == 'T' and maximum_days != 14:
                        print(f"Error: Textbook {book_id_number} has invalid max borrowing days.") # Prints error messages for invalid book details
                        return
                    
                    
                    if book_typeof == 'F' and maximum_days <= 14:
                        print(f"Error: Fiction {book_id_number} has invalid max borrowing days.")
                        return
                    
                    # Update or add the book to self.books dictionary
                    if book_id_number not in self.books:
                        self.books[book_id_number] = Book(book_id_number, book__name, book_typeof, copies__number, maximum_days, late__charges)
                    else:
                        book = self.books[book_id_number]
                        book.book__name = book__name
                        book.book_typeof = book_typeof
                        book.copies__number = copies__number
                        
                        book.maximum_days = maximum_days
                        book.late__charges = late__charges
                        
        except FileNotFoundError:
            
            print(f"Error: The file {file_book__name} was not found.")
            
            

   
        
        

    def display_recs(self):  #Prints a table showing which books each member has borrowed, with borrowed days,
    # and summary statistics including total number of books, total number of members,
    # and average number of days books have been borrowed.
        if not self.books:
            print("No records to display.")
            return
#   # Get sorted lists of member IDs and book IDs
        member_ids = sorted(self.members.keys())
        
        book_id_numbers = sorted(self.books.keys())
## Create the header for the table
        heading = "Member ID " + " ".join([f"{book_id_number:<5}"  for book_id_number
        in book_id_numbers])
        
        print(heading)
        ## Printing a line of dashes to separate the header from the data rows
        print("-" * len(heading))
## Iterate over each member ID and print their borrowing records
        for member_id in member_ids:
            
            row = f"{member_id:<10}"
            
            for book_id_number in book_id_numbers:
                # # Format the days borrowed or indicate if there's a reservation ('R')
                days = self.books[book_id_number].gettingborrowedday(member_id)
                
                if days == 'R':
                    row += f"{'--':>5} "
                else:
                    row += f"{days:>5} "
            print(row) # # Print the row for the current member

        total_books = len(self.books) # # Calculate total number of books
        
        total_days = sum(
            int(days) for book in self.books.values() 
            for days in book.days_borrow.values() if days.isdigit()
        ) # # Calculate total number of days books have been borrowed and average days
        avg_days = total_days / total_books if total_books else 0
        total_members = len(self.members) # # Calculate total number of members
# # Print summary statistics
        print(f"\nTotal number of books: {total_books}")
        
        print(f"Total number of members: {total_members}")
        
        print(f"Average number of days books have been borrowed: {avg_days:.2f}")
        
        
        

    def displaybooks_deets(self):  # Display detailed information about each book
    #  Prints a table showing book details including book ID, name, type, number of copies,
    # maximum days allowed for borrowing, late charges, number of times borrowed,
    # number of reservations ('appointments'), and range of days borrowed.
        
        if not self.books: # If there are no books, prints a message indicating no information is available.
            print("No book information to display.")
            return

        heading = "Book ID  book__name            Type     Ncopy  Maxday  Lcharge  Nborrow  Nreserve  Range"
        print(heading)
        print("-" * len(heading))
# # Iterate over each book ID and book object in self.books dictionary
        for book_id_number, book in self.books.items():
            
            nborrow, nappoints, minimum_day, maximum_days = book.get_calc()
            # # Format days range as minimum-maximum, or 'xx-xx' if no data available
            days_range = f"{minimum_day}-{maximum_days}" if minimum_day is not None else "xx-xx"
             # Format the row with book details
            row = f"{book_id_number:<8} {book.book__name:<15} {book.book_typeof:<8} {book.copies__number:<5} {book.maximum_days:<6} {book.late__charges:<8.2f} {nborrow:<8} {nappoints:<8} {days_range}"
            print(row)
    
    
    
    def member_deets(self, file_book__name): # Read member details from a file and update the records
     try: 
         
        with open(file_book__name, 'r') as file:
            
            for line in file:
                phase = line.strip().split(', ') # # Split the line into parts and strip whitespace
                if len(phase) < 5:
                   # print(f"Error: Missing fields in line: {line.strip()}") #rints error message for missing fields in a line or if the file is not found.
                    continue
                # # Extract attributes from the line
                member_id = phase[0]
                Fnameofbook = phase[1]
                Lnameofbook = phase[2]
                date_of_birth = phase[3]
                member_typeof = phase[4]
                # # Update or add the member to self.members dictionary
                if member_id not in self.members:
                    self.members[member_id] = Member(member_id, Fnameofbook, Lnameofbook, date_of_birth, member_typeof)
                else:
                    member = self.members[member_id]
                    member.Fnameofbook = Fnameofbook
                    
                    member.Lnameofbook = Lnameofbook
                    member.date_of_birth = date_of_birth
                    member.member_typeof = member_typeof
                    
     except FileNotFoundError: 
         
        print(f"Error: The file {file_book__name} was not found.")

   

    def keep_info(self, file_book__name): # Write member information including borrowing statistics to a file.
        
        with open(file_book__name, 'w') as file: #  # Write the header for the file
            
            heading = "Member ID, Fbook__name, Lbook__name, Type, date_of_birth, Ntextbook, Nfiction, Average"
            file.write(heading + "\n")
            ## Iterate over sorted members and write their details to the file
            for member_id, member in sorted(self.members.items()):
                 # Get calculated values from the member
                n_textbook, n_fiction, avg_days = member.get_calc()
                limit_check = member.book_kind()
                # # Construct the row to write to the file
                row = f"{member_id}, {member.Fnameofbook}, {member.Lnameofbook}, {member.member_typeof}, {member.date_of_birth}, "
                 # Append number of textbooks borrowed, handling 'Ntextbook!' warning
                if "Ntextbook!" in limit_check:
                    row += f"{n_textbook}!, "
                    
                else: # # Append number of fictional books borrowed, handling 'Nfiction!' warning
                    row += f"{n_textbook}, "
                if "Nfiction!" in limit_check:
                    row += f"{n_fiction}!, "
                    
                else:## Append average days borrowed
                    row += f"{n_fiction}, "
                row += f"{avg_days:.2f}"
                file.write(row + "\n") # # Write the constructed row to the file
                
                
    def read_recs(self, file_book__name):
        try:
            with open(file_book__name, 'r') as file:
                for line in file:
                    
                    phase = line.strip().split(', ')
                    book_id_number = phase[0]
                    
                    if book_id_number not in self.books:
                        self.books[book_id_number] = Book(book_id_number, "", "", 0, 0, 0)
                        
                    for record in phase[1:]:
                        member_id, days = record.split(': ')
                        
                        if member_id not in self.members:
                            self.members[member_id] = Member(member_id, "", "", "", "")
                            
                        self.books[book_id_number].addingborrowday(member_id, days)
                        
                        if days != 'R':
                            self.members[member_id].add_book(self.books[book_id_number].book_typeof, int(days))
                        else:
                            
                            self.members[member_id].add_book(self.books[book_id_number].book_typeof,
                                                             days)
                            
        except FileNotFoundError:
            print(f"Error: The file {file_book__name} was not found.")
            
##############################################################################

if __name__ == "__main__":
   # the file names for records, books, and members
    records_file = 'records.txt'
    book_file = 'books.txt'
    member_file = 'members.txt'

    records = Records() # # Create an instance of Records
    records.read_recs(records_file) # # Read records from 'records.txt' and update records in records.books and records.members
    records.read_recs(records_file)
    records.book_deets(book_file) # # Read book details from 'books.txt' and update records in records.books
    records.member_deets(member_file)# Read member details from 'members.txt' and update records in records.members

    records.display_recs() # # Display records of members borrowing books
    records.displaybooks_deets() ## Display detailed information about books
    records.displaymember_deets() # # Display detailed information about members
    records.keep_info("reports.txt") ## Keep member information with borrowing statistics in 'reports.txt'

    most_active_member = max(records.members.values(), key=lambda m: len(m.borrowed_books.get('T', [])) + len(m.borrowed_books.get('F', []))) # # Find the most active member based on the number of borrowed books
    least_avg_days_member = min(records.members.values(), key=lambda m: m.avg_days()) # # Find the member with the least average borrowing days

## Print results
    print(f"\nThe most active member(s): {most_active_member.Fnameofbook} {most_active_member.Lnameofbook} ({len(most_active_member.borrowed_books.get('T', [])) + len(most_active_member.borrowed_books.get('F', []))} books)")
    print(f"The member(s) with the least average borrowing days: {least_avg_days_member.Fnameofbook} {least_avg_days_member.Lnameofbook} ({least_avg_days_member.avg_days():.2f} days)")
    
##############################################################################    
# Member Class
# Attributes:

# member_id: Unique identifier for the member.

# Fnameofbook: First name of the member.

# Lnameofbook: Last name of the member.
# date_of_birth: Date of birth of the member.
# member_typeof: Type of membership (Standard or Premium).
# borrowed_books: Dictionary to store borrowed books categorized by type ('T' for textbooks, 'F' for fictional books).
# Methods:

# book_kind(): Determines if the member has borrowed more books than allowed based on membership type.
# get_calc(): Returns the number of textbooks and fictional books borrowed, and the average number of days books are borrowed.
# avg_days(): Calculates the average number of days books are borrowed by the member.
# numberof_textbooks(): Counts the number of textbooks borrowed.
# add_book(book_typeof, days): Adds a book to the member's borrowed books list.
# numberof_fictionalbooks(): Counts the number of fictional books borrowed.


# Book Class
# Attributes:

# book_id_number: Unique identifier for the book.
# book__name: Name of the book.
# book_typeof: Type or category of the book.
# copies__number: Number of copies available.
# maximum_days: Maximum days allowed for borrowing the book.
# late__charges: Charges applicable if the book is returned late.
# days_borrow: Dictionary to store borrowing information for members.


# Methods:

# numberof_borrow_member(): Counts the number of members who have borrowed the book.
# addingborrowday(member_id, days): Adds or updates the borrowing days for a member.
# get_calc(): Returns the number of members who have borrowed the book, number of reservations, and the range of borrowing days.
# number_appointments(): Counts the number of reservations.
# borrow_duration(): Returns the minimum and maximum days a book has been borrowed.
# gettingborrowedday(member_id): Returns the number of days a member has borrowed the book.


# Records Class
# Attributes:

# books: Dictionary to store book records where keys are book IDs.
# members: Dictionary to store member records where keys are member IDs.
# Methods:

# displaymember_deets(): Displays detailed information about each member.
# book_deets(file_book__name): Reads book details from a file and updates the records.
# display_recs(): Displays records of members borrowing books.
# displaybooks_deets(): Displays detailed information about each book.
# member_deets(file_book__name): Reads member details from a file and updates the records.
# keep_info(file_book__name): Writes member information including borrowing statistics to a file.
# read_recs(file_book__name): Reads records from a file and updates the book and member records.


# Main Execution:
# The main block of the code:
# Initializes file names for records, books, and members.
# Creates an instance of Records.
# Reads records from records.txt and updates records in records.books and records.members.
# Reads book details from books.txt and member details from members.txt.
# Displays records of members borrowing books.
# Displays detailed information about books.
# Displays detailed information about members.
# Keeps member information with borrowing statistics in reports.txt.
# Finds and prints the most active member and the member with the least average borrowing days.