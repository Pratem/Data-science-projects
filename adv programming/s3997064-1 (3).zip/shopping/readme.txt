
STUDENT NUMBER:s3997064

****************Here are few important information about my assignment.*****************

>The processed csv  file what u see in the zip file is obtained from the milestone1_task1 jupyter notebook
as i have used the assignment3_II csv file to get it processed . (without trained model)

>This processed csv file  is then used on the language model and classified 

*****************Here are some points on the running the python  file on command prompt****************

> First creating the new virtual environment
conda create -- name projectshopping python=3.9.5  #(projectshopping can be any name)

>activate projectshopping

>installing libararies. In my assigmnment the folling libraries has to be installed in the command prompt 
pip install flask pandas numpy scikit-learn gensim       #(very important) 

> cd (path to the directory )

>set FLASK_APP=app1234   ( here the pyhton file name is app1234)

>run flask

>copy the URL on the browswer to access the webpage

