#!/usr/bin/env python
# coding: utf-8

# In[2]:


import os
import pandas as pd
from flask import Flask, request, render_template, redirect, url_for
from sklearn.linear_model import LogisticRegression
import gensim.downloader as api
from gensim.models import Word2Vec
import numpy as np


# In[3]:


app = Flask(__name__)

# Load the processed data
df = pd.read_csv('processed.csv')

# Load the Word2Vec model
word2vec_model = api.load('word2vec-google-news-300')

# Fill NaN values with empty strings
df['Processed_Review_Text'].fillna('', inplace=True)


# In[9]:


# Function to convert text to vector using Word2Vec
def text_to_vector(text):
    words = text.split()
    word_vectors = [word2vec_model[word] for word in words if word in word2vec_model]
    if word_vectors:
        return np.mean(word_vectors, axis=0)
    else:
        return np.zeros(word2vec_model.vector_size)


# In[10]:


# Transform the processed review text into vectors
review_vectors = np.array([text_to_vector(text) for text in df['Processed_Review_Text']])

# Train the logistic regression model
labels = df['Recommended IND'].values
model = LogisticRegression(max_iter=1000)
model.fit(review_vectors, labels)


# In[11]:


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        query = request.form['query']
        results = df[df['Clothes Title'].str.contains(query, case=False, na=False) |
                     df['Clothes Description'].str.contains(query, case=False, na=False)]
        return render_template('search_results.html', query=query, results=results)
    return render_template('search.html')

@app.route('/item/<int:item_id>')
def item(item_id):
    item = df[df['Clothing ID'] == item_id].iloc[0]
    reviews = df[df['Clothing ID'] == item_id]
    return render_template('item.html', item=item, reviews=reviews)

@app.route('/add_review/<int:item_id>', methods=['GET'])
def add_review(item_id):
    item = df[df['Clothing ID'] == item_id].iloc[0]
    return render_template('add_review.html', item=item)

@app.route('/submit_review/<int:item_id>', methods=['POST'])
def submit_review(item_id):
    try:
        title = request.form['title']
        review_text = request.form['review_text']
        rating = int(request.form['rating'])
        
        # Preprocess the review text
        processed_review = preprocess_review(review_text)
        
        # Generate recommendation label
        review_vector = text_to_vector(processed_review).reshape(1, -1)
        predicted_recommendation = model.predict(review_vector)[0]
        
        # Allow user to override the recommendation
        recommendation = request.form.get('recommendation', predicted_recommendation)
        
        # Save the review (for simplicity, appending to the DataFrame)
        new_review = pd.DataFrame({
            'Clothing ID': [item_id],
            'Title': [title],
            'Review Text': [review_text],
            'Rating': [rating],
            'Recommended IND': [recommendation]
        })
        global df
        df = pd.concat([df, new_review], ignore_index=True)
        
        # Redirect to the item details page
        return redirect(url_for('item', item_id=item_id))
    
    except Exception as e:
        return render_template('error.html', error=str(e))

@app.route('/reviews/<int:item_id>')
def reviews(item_id):
    item_reviews = df[df['Clothing ID'] == item_id]
    return render_template('reviews.html', reviews=item_reviews)

def preprocess_review(review_text):
    # Tokenize, convert to lowercase, and remove short words
    tokens = [word.lower() for word in review_text.split() if len(word) > 1]
    return ' '.join(tokens)

if __name__ == '__main__':
    app.run(debug=True)


# In[ ]:




