#!/usr/bin/env python
# coding: utf-8

# # Assignment 2: Milestone I Natural Language Processing
# ## Task 1. Basic Text Pre-processing
# #### Student Name: Pratham Radhakrishna
# #### Student ID: S3997064
# 
# ## Introduction
# Objective
# The objective of Task 1 is to perform basic text pre-processing on a dataset of clothing reviews. The focus is on cleaning and preparing the "Review Text" column for further analysis and model building. This task involves several steps to ensure the text data is in a suitable format for feature extraction and machine learning.
# 
# Steps Involved
# Extract Information About the Review:
# 
# Load the dataset and examine its structure.
# Identify and handle missing values in the "Review Text" column.
# Tokenization:
# 
# Tokenize each clothing review using the specified regular expression r"[a-zA-Z]+(?:[-'][a-zA-Z]+)?".
# Tokenization involves splitting the text into individual words or tokens.
# Convert to Lowercase:
# 
# Convert all words to lowercase to ensure uniformity and reduce redundancy.
# Remove Short Words:
# 
# Remove words with a length less than 2 characters, as they are often not meaningful.
# Remove Stopwords:
# 
# Remove common stopwords using a provided stop words list (stopwords_en.txt).
# Stopwords are words that are frequently used but carry little informational value (e.g., "and", "the", "is").
# Remove Words that Appear Only Once:
# 
# Identify and remove words that appear only once in the entire document collection, as they may not contribute significantly to the analysis.
# Remove the Top 20 Most Frequent Words:
# 
# Calculate the document frequency for each word.
# Identify and remove the top 20 most frequent words to reduce noise and focus on more informative words.
# Save the Processed Data:
# 
# Save the cleaned and processed review text to a new CSV file (processed.csv).
# Build a Vocabulary:
# 
# Create a vocabulary of the cleaned/processed reviews.
# Save the vocabulary to a text file (vocab.txt) with each word and its corresponding index.
# 
# 

# ## Importing libraries 

# In[1]:


# Code to import libraries as you need in this assessment, e.g.,
import pandas as pd

import re
from nltk import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize
import nltk
from collections import Counter
nltk.download('stopwords')
nltk.download('punkt')
from nltk.probability import FreqDist


# ### 1.1 Examining and loading data
# - Examine the data and explain your findings
# - Load the data into proper data structures and get it ready for processing.

# In[2]:


# Code to inspect the provided data file...

df = pd.read_csv('assignment3.csv')
df.head()
#**Data Overview**:
#   - The dataset contains 19662 rows and 10 columns.
#   - The columns include various attributes of clothing reviews such as 'Clothing ID', 'Age', 'Title', 'Review Text', 'Rating', 'Recommended IND', etc.


# In[3]:


df.info()


# In[4]:


print("\nSummary statistics of the dataset:")
print(df.describe())


# In[5]:


# Check for missing values
print("\nMissing values in the dataset:")
print(df.isnull().sum())
# no null values in any of the columns 


# In[6]:


# Displaying unique values in 'Recommended IND' column to understand the labels
print("\nUnique values in 'Recommended IND' column:")
print(df['Recommended IND'].unique())


# In[7]:


#Displaying the distribution of 'Recommended IND' column
print("\nDistribution of 'Recommended IND' column:")
print(df['Recommended IND'].value_counts())


# ### 1.2 Pre-processing data
# 

# In[8]:


# Loading the stopwords from file
stopwords_file = 'stopwords_en.txt'  
with open(stopwords_file, 'r') as file:
    stop_words = set(file.read().splitlines())


# In[9]:


#Step 2: Tokenize Each Clothing Review
#Using RegexpTokenizer to tokenize words based on the specified regular expression.

# Defining the tokenization function using RegexpTokenizer
def tokenize(text):
    tokenizer = RegexpTokenizer(r"[a-zA-Z]+(?:[-'][a-zA-Z]+)?")
    tokens = tokenizer.tokenize(text)
    return tokens


# In[10]:


# Applying tokenization to the 'Review Text' column
df['Tokenized_Review'] = df['Review Text'].apply(lambda x: tokenize(x) if pd.notnull(x) else [])


# In[11]:


#Step 3: Converting All Words to Lowercase and Remove Words with a Length Less than 2
# Defineing the function to process tokens: convert to lowercase and remove short words
def process_tokens(tokens):
    # Converting to lowercase and remove words with length less than 2
    processed_tokens = [word.lower() for word in tokens if len(word) >= 2]
    return processed_tokens

# Applying lowercase conversion and short word removal
df['Processed_Review'] = df['Tokenized_Review'].apply(process_tokens)


# In[12]:


#Step 4: Removing Stopwords
# Defineing the function to remove stopwords
def remove_stopwords(tokens):
    filtered_tokens = [word for word in tokens if word not in stop_words]
    return filtered_tokens

# Applying stop words removal
df['Processed_Review'] = df['Processed_Review'].apply(remove_stopwords)


# In[13]:


#Step 5: Removing Words that Appear Only Once in the Document Collection
# Flatten the list of all tokens
all_tokens = [word for tokens in df['Processed_Review'] for word in tokens]

# Calculating the frequency of each word
word_freq = Counter(all_tokens)

# Removing words that appear only once
df['Processed_Review'] = df['Processed_Review'].apply(lambda tokens: [word for word in tokens if word_freq[word] > 1])


# In[14]:



# Calculate document frequency for each word using FreqDist
doc_freq = FreqDist()
for tokens in df['Processed_Review']:
    doc_freq.update(set(tokens))

# Get the top 20 most frequent words
most_frequent_words = set([word for word, freq in doc_freq.most_common(20)])

# Remove the top 20 most frequent words from the processed reviews
df['Processed_Review'] = df['Processed_Review'].apply(lambda tokens: [word for word in tokens if word not in most_frequent_words])


# In[15]:


#Step 7: Save the Processed Data as processed.csv
# Joining the processed tokens back into a single string for each review
df['Processed_Review_Text'] = df['Processed_Review'].apply(lambda tokens: ' '.join(tokens))

# Save the processed data to a CSV file
df.to_csv('processed.csv', index=False)


# ## Saving required outputs
# Save the requested information as per specification.
# - vocab.txt

# In[16]:


# code to save output data...
#Step 8: Building a Vocabulary of the Cleaned/Processed Reviews and Save it in a vocab.txt File
# Build the vocabulary
vocabulary = sorted(set(word for tokens in df['Processed_Review'] for word in tokens))

# Create a dictionary with word indices
vocab_dict = {word: idx for idx, word in enumerate(vocabulary)}

# Save the vocabulary to a txt file
with open('vocab.txt', 'w') as file:
    for word, idx in vocab_dict.items():
        file.write(f"{word}:{idx}\n")


# ## Summary
# The objective of Task 1 is to clean and prepare the "Review Text" from a dataset of clothing reviews for further analysis. The steps include loading the dataset, handling missing values, tokenizing the text using a specified regular expression, converting words to lowercase, and removing words with fewer than 2 characters. Additionally, common stopwords are removed using a provided list, and words that appear only once or are among the top 20 most frequent are filtered out. The cleaned review text is saved to processed.csv, and a vocabulary of the processed text is built and saved to vocab.txt. This results in a dataset ready for feature extraction and machine learning, along with a corresponding vocabulary file.

# In[17]:


df


# In[ ]:




