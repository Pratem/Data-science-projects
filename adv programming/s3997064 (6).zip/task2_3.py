#!/usr/bin/env python
# coding: utf-8

# # Assignment 2: Milestone I Natural Language Processing
# ## Task 2&3
# #### Student Name:Pratham Radhakrishna
# #### Student ID: S3997064
# 
# 
# ## Introduction
# Objective
# The goal of Task 2 is to generate various feature representations for the clothing item reviews to be used in machine learning models. This involves creating different types of vector representations based on the processed review text.
# 
# Key Steps
# Bag-of-Words Model:
# 
# Count Vector Representation: Generate the count vector representation for each review using the vocabulary created in Task 1. This representation captures the frequency of each word in the review.
# Word Embedding Models:
# 
# Choose a Pre-trained Embedding Model: Select a pre-trained word embedding model such as Word2Vec, GloVe, or FastText.
# Unweighted Embedding Representation: Generate an unweighted vector representation for each review by averaging the word embeddings of all words in the review.
# TF-IDF Weighted Embedding Representation: Generate a TF-IDF weighted vector representation for each review by weighting the word embeddings according to their TF-IDF scores.
# Required Output
# Count Vectors:
# 
# count_vectors.txt: Stores the sparse count vector representation of each review. Each line corresponds to one review and includes the review index and word frequencies in the format word_index:word_freq.
# Embedding Vectors:
# 
# unweighted_vectors.npy: A NumPy file storing the unweighted embedding vectors for each review.
# weighted_vectors.npy: A NumPy file storing the TF-IDF weighted embedding vectors for each review.
# 
# Objective
# The goal of Task 3 is to build and evaluate machine learning models to classify whether a clothing item is recommended based on its review text. This involves comparing different feature representations and exploring the impact of additional information on model accuracy.
# 
# Key Steps
# Language Model Comparisons:
# 
# Objective: Determine which feature representation (from Task 2) performs best with a logistic regression model.
# Approach: Train and evaluate logistic regression models using count vectors, unweighted embedding vectors, and TF-IDF weighted embedding vectors. Perform 5-fold cross-validation to obtain robust performance metrics.
# Impact of Additional Information:
# 
# Objective: Assess whether adding extra information (e.g., the review title) improves model accuracy.
# Approach: Conduct experiments using three different sets of features:
# Only the title of the review.
# Only the review text.
# Both the title and the review text combined.
# Evaluation: Use logistic regression and 5-fold cross-validation to compare the accuracy of models using these different feature sets.
# 

# ## Importing libraries 

# In[1]:


# Code to import libraries as you need in this assessment, e.g.,
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
get_ipython().system('pip install --user gensim')
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score


# ## Task 2. Generating Feature Representations for Clothing Items Reviews

# ...... Sections and code blocks on buidling different document feature represetations
# 
# 
# <span style="color: red"> You might have complex notebook structure in this section, please feel free to create your own notebook structure. </span>

# In[2]:


# Code to perform the task...
# Load the processed data
df = pd.read_csv('processed.csv')

# Load the vocabulary
vocab_file = 'vocab.txt'
vocab = {}
with open(vocab_file, 'r') as file:
    for line in file:
        word, idx = line.strip().split(':')
        vocab[word] = int(idx)


# In[3]:


# Fill NaN values with empty strings
df['Processed_Review_Text'].fillna('', inplace=True)
df


# In[4]:


# Create a CountVectorizer with the loaded vocabulary
vectorizer = CountVectorizer(vocabulary=vocab)


# In[5]:


# Fit and transform the processed review text to get the count vectors
count_matrix = vectorizer.transform(df['Processed_Review_Text'])


# In[6]:


# Generate the sparse representation of count vectors
count_vectors = []
for idx, row in enumerate(count_matrix):
    non_zero_indices = row.nonzero()[1]
    count_vector = [f"{i}:{row[0, i]}" for i in non_zero_indices]
    count_vectors.append(f"#{idx}," + ",".join(count_vector))

# Save the Count vector representation to a file
with open('count_vectors.txt', 'w') as file:
    for vector in count_vectors:
        file.write(vector + '\n')


# In[7]:


get_ipython().system('pip show gensim')


# In[8]:


import gensim.downloader as api


# In[9]:


# Load the pre-trained Word2Vec model
word2vec_model = api.load('word2vec-google-news-300')


# In[10]:



# Generate unweighted embedding representation
unweighted_vectors = []
for index, row in df.iterrows():
    review_text = row['Processed_Review_Text'].split()
    embeddings = [word2vec_model[word] for word in review_text if word in word2vec_model]
    if embeddings:
        unweighted_vector = np.mean(embeddings, axis=0)
    else:
        unweighted_vector = np.zeros(300)
    unweighted_vectors.append(unweighted_vector)


# In[11]:


# Generate TF-IDF weights
tfidf = TfidfVectorizer(vocabulary=vocab)
tfidf_matrix = tfidf.fit_transform(df['Processed_Review_Text'])

# Generate TF-IDF weighted embedding representation
weighted_vectors = []
for index, row in df.iterrows():
    review_text = row['Processed_Review_Text'].split()
    embeddings = []
    tfidf_weights = []
    for word in review_text:
        if word in word2vec_model and word in vocab:
            embeddings.append(word2vec_model[word])
            tfidf_weights.append(tfidf_matrix[index, vocab[word]])
    if embeddings and np.sum(tfidf_weights) != 0:
        weighted_vector = np.average(embeddings, axis=0, weights=tfidf_weights)
    else:
        weighted_vector = np.mean(embeddings, axis=0) if embeddings else np.zeros(300)
    weighted_vectors.append(weighted_vector)


# In[ ]:





# ### Saving outputs
# Save the count vector representation as per spectification.
# - count_vectors.txt

# In[12]:


# Save the Count vector representation to a file
with open('count_vectors.txt', 'w') as file:
    for vector in count_vectors:
        file.write(vector + '\n')


# In[13]:


# Save unweighted embedding vectors to a file
np.save('unweighted_vectors.npy', np.array(unweighted_vectors))


# In[14]:


# Save weighted embedding vectors to a file
np.save('weighted_vectors.npy', np.array(weighted_vectors))


# ## Task 3. Clothing Review Classification

#  Language model comparisons

# In[15]:



labels = df['Recommended IND'].values
labels


# In[16]:


# Load the Count vectors
with open('count_vectors.txt', 'r') as file:
    count_vectors = [line.strip().split(',') for line in file]


# In[17]:


# Load the unweighted and weighted embedding vectors
unweighted_vectors = np.load('unweighted_vectors.npy')
weighted_vectors = np.load('weighted_vectors.npy')


# In[18]:


# Convert count_vectors to a sparse matrix
vectorizer = CountVectorizer(vocabulary=vocab)
count_matrix = vectorizer.transform([' '.join(vec[1:]) for vec in count_vectors])


# In[19]:


def evaluate_model(X, y, model, cv=5):
    scores = cross_val_score(model, X, y, cv=cv, scoring='accuracy')
    return scores.mean(), scores.std()


# In[20]:


# Initialize the logistic regression model
logreg = LogisticRegression(max_iter=1000)

# Evaluate Count Vectors
mean_acc_count, std_acc_count = evaluate_model(count_matrix, labels, logreg)
print(f"Count Vectors - Mean Accuracy: {mean_acc_count}, Std: {std_acc_count}")

# Evaluate Unweighted Embedding Vectors
mean_acc_unweighted, std_acc_unweighted = evaluate_model(unweighted_vectors, labels, logreg)
print(f"Unweighted Embedding Vectors - Mean Accuracy: {mean_acc_unweighted}, Std: {std_acc_unweighted}")

# Evaluate Weighted Embedding Vectors
mean_acc_weighted, std_acc_weighted = evaluate_model(weighted_vectors, labels, logreg)
print(f"Weighted Embedding Vectors - Mean Accuracy: {mean_acc_weighted}, Std: {std_acc_weighted}")


# Unweighted Embedding Vectors have the highest mean accuracy (0.8577) among the three models, indicating that this model performs the best in terms of accuracy.
# Count Vectors have the lowest mean accuracy (0.8181).
# The standard deviations indicate the variability of the accuracy across the folds in cross-validation. The unweighted embedding vectors also have a relatively low standard deviation (0.0024), suggesting that the model's performance is consistent.

# : Does more information provide higher accuracy?

# In[21]:


#Only Title of the Review:
# Load the title data
df['Title'].fillna('', inplace=True)
titles = df['Title'].values

# Convert titles to count vectors
title_vectorizer = CountVectorizer()
title_matrix = title_vectorizer.fit_transform(titles)

# Evaluate Title Vectors
mean_acc_title, std_acc_title = evaluate_model(title_matrix, labels, logreg)
print(f"Title Vectors - Mean Accuracy: {mean_acc_title}, Std: {std_acc_title}")


# In[22]:


#Both Title and Detailed Review:
# Concatenate title and review text
df['Title_Review'] = df['Title'] + ' ' + df['Processed_Review_Text']
title_review_matrix = title_vectorizer.fit_transform(df['Title_Review'])

# Evaluate Title + Review Vectors
mean_acc_title_review, std_acc_title_review = evaluate_model(title_review_matrix, labels, logreg)
print(f"Title + Review Vectors - Mean Accuracy: {mean_acc_title_review}, Std: {std_acc_title_review}")


# Only Title of the Review has a mean accuracy of 0.8840, which is higher than the mean accuracy of using only the description/text of the review (0.8577).
# Both Title and Detailed Review have the highest mean accuracy (0.8985), indicating that combining both the title and the review text provides the best performance.
# Based on the mean accuracy and standard deviation, the model that uses both the title and the detailed review performs the best for classifying the recommendation of an item review text. This suggests that adding extra information (the title) helps to boost the accuracy of the model.

# ## Summary

#  In Task 3, the objective is to build and evaluate logistic regression models to classify whether a clothing item is recommended based on its review text. This involves comparing different feature representations generated in Task 2, including count vectors, unweighted embedding vectors, and TF-IDF weighted embedding vectors, using 5-fold cross-validation to determine which performs best. Additionally, the task explores whether incorporating extra information, such as the review title, improves model accuracy by comparing models using only the title, only the review text, and both combined. The results provide insights into the most effective feature representation and the impact of additional information on classification performance.

# In[ ]:




